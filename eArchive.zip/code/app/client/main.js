
/**
 * Authors - Mit, Raj, Prabhjot, Nill, Dylan, Mouli
 * Project Website - https://github.com/Mitbits/Software-Project
*/

import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';


import './main.html';



