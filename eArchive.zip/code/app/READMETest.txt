1)stop meteor if running
2)from within app folder run
meteor test --driver-package practicalmeteor:mocha

